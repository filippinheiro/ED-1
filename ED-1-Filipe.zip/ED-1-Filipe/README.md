# ExercíciosED
Exercícios ED feito em aula
