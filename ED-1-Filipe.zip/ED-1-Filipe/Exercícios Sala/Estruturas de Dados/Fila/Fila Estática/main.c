#include "fila.h"

int main(){
    Fila* f = criarFila();
    return 0;
}