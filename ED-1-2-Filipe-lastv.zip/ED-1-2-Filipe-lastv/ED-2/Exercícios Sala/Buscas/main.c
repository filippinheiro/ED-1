#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buscas.h"

int main() {
	printf("Digite um texto\n >> ");
	char Texto[80];
	setbuf(stdin, NULL);
	scanf("%80[^\n]", Texto);
	printf("Digite um padrão\n >> ");
	char Padrao[80];
	setbuf(stdin, NULL);
	scanf("%80[^\n]", Padrao);
	int indice = forcaBruta(Texto, strlen(Texto), Padrao, strlen(Padrao));
	int i, j = 0;
	if(indice != -1) {
		for(i=indice; j < strlen(Padrao); i++) {
			printf("%c", Texto[i]);
			j++;
		}
		printf("\n");
	} else 
		printf("Padrão não encontrado\n");
	return 0; 
}  