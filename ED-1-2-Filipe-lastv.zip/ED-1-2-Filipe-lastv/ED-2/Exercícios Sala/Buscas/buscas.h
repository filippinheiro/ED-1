#ifndef BUSCAS_H
#define BUSCAS_H

int forcaBruta(char*, int, char*, int);

#endif