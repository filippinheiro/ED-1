
#include <stdio.h>

int forcaBruta(char* t, int n, char* p, int m) {
	int b = n-m; 
	if(b >= 0) {
		int i;
		int c = 1;
		for(i = 0; i<=b; i++){
			int j = 0;
			printf("%d comparação(s)\n", c);
			while(j < m && t[i+j] == p[j]) {
				j++;
				if(j == m) 
					return i;
			} 

			c++;
		}
	} 
	return -1; 
}


int* knuth_morris(char* p, int m, int* aux){
	int i, j = -1;
	aux[0] = j;
	for(i=1; i<=m-1; i++) {
		while(j > -1 && p[j+1] != p[i]) {
			j = aux[j];
			if(p[i] == p[j+1])
				j++;
			aux[i] = j; 
		} 
	} 
	return aux;
} 